import React from 'react'
import Footer from './Components/Footer'
import Header from './Components/Header'
import ProductList from './Components/ProductList'

const App =()=>{
    return (
        <div>
            <Header></Header>
            <ProductList></ProductList>
            <Footer></Footer>
        </div>
    )
}

export default App