
export default function product_reducer(state=null,action){
    console.log("product reducer",action)
      switch(action.type){
         case 'FETCH_PRODUCTS':
            return action.payload;
         default:
             return state
 }
   
    

}