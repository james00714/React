import {combineReducers} from 'redux'
import preducer from './ProductReducer'

const rootReducer= combineReducers({
    preducer

})

export default rootReducer
