import React ,{Component} from 'react'

class ProductItem extends Component{
   
    constructor(props){
        super(props)
        this.state={

        }
    }
    render(){
        return (
            <div>
               <img src={this.props.image} alt={this.props.name}></img>
               {this.props.name}
            </div>
        )
    }
}

export default  ProductItem 
