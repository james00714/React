import React ,{Component} from 'react'
import ProductItem from './ProductItem'
import json from '../JSON/MusicProducts.json'

class ProductList extends Component{

   constructor (){
       super()
       this.state={
           products:json.products //added a state which will be used in render method to iterate over
       }
   }

    render(){
        //using map method to iterate over array products
        const list= this.state.products?.map((item)=><ProductItem key={item.id} name={item.name} image={item.img}></ProductItem>)
        return (
            <div>
                {list}
            </div>
        )
    }
}

export default ProductList