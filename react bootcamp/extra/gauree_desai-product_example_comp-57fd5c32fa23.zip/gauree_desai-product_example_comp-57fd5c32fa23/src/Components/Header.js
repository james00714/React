import React from 'react'

const Header =()=>{
    return (
        <div>
            <h1>
            This is Header!!
            </h1> 
        </div>
    )
}

export default Header