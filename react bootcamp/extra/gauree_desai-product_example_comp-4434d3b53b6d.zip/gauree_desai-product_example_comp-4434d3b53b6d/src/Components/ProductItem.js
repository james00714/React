import React ,{Component} from 'react'

class ProductItem extends Component{

    render(){
        return (
            <div>
                This is ProductItem
            </div>
        )
    }
}

export default  ProductItem 
