import React ,{Component} from 'react'
import ProductItem from './ProductItem'

class ProductList extends Component{

    render(){
        return (
            <div>
                This is ProductList 
                <ProductItem></ProductItem>
            </div>
        )
    }
}

export default ProductList