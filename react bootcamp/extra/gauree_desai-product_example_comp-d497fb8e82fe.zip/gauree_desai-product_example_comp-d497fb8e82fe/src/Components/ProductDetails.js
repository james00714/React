import React from 'react'

class ProductDetails extends React.Component{
    render(){
        const {params}  = this.props.match
        return (
            <div>
                  ProductDetails The product you have selected product with id :{params.id}
            </div>
        )
       
    }
}

export default ProductDetails 