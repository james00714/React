import axios from 'axios';
import { put, takeLatest, all } from 'redux-saga/effects';


function* fetchProducts() {
  const json = yield axios.get('http://localhost:6700/products')
        .then(response => response.data )   
  yield put({ type: "FETCH_PRODUCTS_SUCCESS", payload: json });
}

function* actionWatcher() {
	
     yield takeLatest('FETCH_PRODUCTS_BEGIN', fetchProducts)
}




export default function* rootSaga() {
   yield all([
   actionWatcher(),
   ]);
}


// const article = { title: 'React POST Request Example' };
// const headers = { 
//     'Authorization': 'Bearer my-token',
//     'My-Custom-Header': 'foobar'
// };
// axios.post('https://reqres.in/api/articles', article, { headers })
//     .then(response => this.setState({ articleId: response.data.id }));
// }