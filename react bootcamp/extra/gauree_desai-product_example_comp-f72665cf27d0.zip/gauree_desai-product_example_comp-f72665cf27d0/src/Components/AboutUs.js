import React from 'react'

const AboutUs =()=>{
    return (
        <div>
            <h1>
            This is AboutUs!!
            </h1> 
        </div>
    )
}

export default AboutUs