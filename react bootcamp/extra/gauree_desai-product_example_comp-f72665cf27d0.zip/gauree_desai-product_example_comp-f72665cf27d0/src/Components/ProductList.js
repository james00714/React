import React ,{Component} from 'react'
import ProductItem from './ProductItem'
//import json from '../JSON/MusicProducts.json'
import {connect} from 'react-redux'
import Loading from './Loading'
//import {fetch_products_api} from '../Actions/ProductActions'

import { fetchProductsBegin } from "../Actions/ProductActions"
import { bindActionCreators} from 'redux';

class ProductList extends Component{

//    constructor (){
//        super()
//        this.state={
//            products:json.products //added a state which will be used in render method to iterate over
//        }
//    }
   componentDidMount(){
       this.props.fetchProductsBegin()
   }

    render(){
         console.log('products props',this.props.products)
        //using map method to iterate over array products
        const list= this.props.products && this.props.products.map((item)=><ProductItem key={item.id} entity={item}></ProductItem>)
        console.log('list:',list)
        return (
            <div>
                <Loading/>
                {list}
            </div>
        )
    }
}

const mapStateToProps=(state)=>{
    console.log('mapStateToProps',state)
      return {
          products:state.preducer.items
      }
  }
  
//   const mapDispatchToProps=(dispatch)=>{
//       return {
//           fetchProducts:()=>dispatch(fetch_products_api())
//       }
//   }
  
function mapDispatchToProps(dispatch){
	return bindActionCreators({fetchProductsBegin},dispatch)
}

  //export default ProductList
  export default connect(mapStateToProps,mapDispatchToProps)(ProductList)