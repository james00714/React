// import json from '../JSON/MusicProducts.json'

//  function fetch_products(){
//     console.log("product action")
//     return {
//         type:'FETCH_PRODUCTS',
//         payload:json.products
//     }
// }
// export default fetch_products;

// export function fetch_products_api(){
//    // if we dispatch this action callin api then payload is sent as blank it doesnt wait for asynchronous call to complete
//     let payload=[];
//     fetch('http://localhost:6700/products',{method:'GET'})
//       .then((response)=>response.json())
//       .then((data)=>{
//           console.log('data from fetch:',data)
//           payload=data
          
//       })
//       return {
//         type:'FETCH_PRODUCTS',
//         payload:payload
//     }
    
// }

export const FETCH_PRODUCTS_BEGIN   = 'FETCH_PRODUCTS_BEGIN';
export const FETCH_PRODUCTS_SUCCESS = 'FETCH_PRODUCTS_SUCCESS';
export const FETCH_PRODUCTS_FAILURE = 'FETCH_PRODUCTS_FAILURE';

export const fetchProductsBegin = () => ({
    type: FETCH_PRODUCTS_BEGIN
  });
 
 export const fetchProductsSuccess = products => ({
   type: FETCH_PRODUCTS_SUCCESS,
   payload:  products 
 });
 
 export const fetchProductsFailure = error => ({
   type: FETCH_PRODUCTS_FAILURE,
   payload: { error }
 });
